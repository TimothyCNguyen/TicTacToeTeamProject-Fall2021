package groupprojectv2;

public class Player implements Comparable<Player> {
    private String name;
    private int age;
    private int winCount;
    private int loseCount;
    
    public Player(String name, int age)
            //throws InvalidAge
    {
        if (age < 0) {
            //throw new InvalidAge(age);
            System.out.println("Invalid Age. Age will be set to 0.");
            age = 0;
        }
        this.name = name;
        this.age = age;
        this.winCount = 0;
        this.loseCount = 0;
    }
    
    public String getName() {
        return String.format("%s", name);
    }

    public int getAge() {
        return age;
    }
    
    public int getWinCount() {
        return winCount;
    }
    public int getLoseCount() {
        return loseCount;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public void addWinCount() {
        this.winCount += 1;
    }
    public void addLoseCount() {
        this.loseCount += 1;
    }
    
    @Override
    public int compareTo(Player a) {
        if (winCount > a.winCount) {
            return 1;
        }
        else if (winCount < a.winCount) {
            return -1;
        }
        else {
            return 0;
        }
    }
    
    @Override
    public String toString(){
        return String.format("name = %s, age = %d, win = %d, lose = %d",
                name, age, winCount, loseCount);
    }
}