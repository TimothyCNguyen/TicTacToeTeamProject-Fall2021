package groupprojectv2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayerHash {
    
    public static void searchByAge(Player[] list, int currentPlayerCount, int age)
    {
    boolean results = false;
        Map<Integer, List<Player>> byAge = new HashMap<>();    

        List<Player> people = new ArrayList<>();
        for (int i = 0; i < currentPlayerCount; i++) {
            people.add(list[i]);
        }
        byAge.put(age, people);
        List<Player> ageList = byAge.get(age);
    
        for (int i = 0; i < ageList.size(); i++) {
            if (ageList.get(i).getAge() == age) {
            System.out.println(ageList.get(i).getName());
            results = true;
            }
        }
        if (results == false) {
            System.out.println("No players found");
        }
    }
}