package groupprojectv2;

//package lab9week9;
import java.util.ArrayDeque;

public final class OurDequeModified<T> implements DequeInterface<T>{
    private ArrayDeque<T> deque;
    private static final int DEFAULT_CAPACITY = 50;
    private static final int MAX_CAPACITY = 10000;
    
    public OurDequeModified() {
        this(DEFAULT_CAPACITY);
    }
    
    public OurDequeModified(int initialCapacity) {
        if (initialCapacity <= MAX_CAPACITY) {
        deque = new ArrayDeque<>(initialCapacity);
        }
        else {
        throw new IllegalStateException("Attempt to create a deque whose "
                                        + "capacity exceeds allowed maximum.");
        }
    }
    
    @Override
    public void addToFront(T newEntry) {
        deque.addFirst(newEntry);
    }
    @Override
    public void addToBack(T newEntry) {
        deque.addLast(newEntry);
    }
    @Override
    public T removeFront() {
    if (isEmpty()) {
        throw new EmptyQueueException();
        }
        T front = deque.removeFirst();
        return front;
    }
    @Override
    public T removeBack() {
    if (isEmpty()) {
        throw new EmptyQueueException();
        }
        T back = deque.removeLast();
        return back;
    }
    @Override
    public T getFront() {
    if (isEmpty()) {
        throw new EmptyQueueException();
        }
        T front = deque.getFirst();
        return front;
    }
    @Override
    public T getBack() {
    if (isEmpty()) {
        throw new EmptyQueueException();
        }
        T back = deque.getLast();
        return back;
    }
    public int getSize() {
    if (isEmpty()) {
        throw new EmptyQueueException();
        }
        int size = deque.size();
        return size;
    }
    @Override
    public boolean isEmpty() {
        return deque.isEmpty();
    }
    @Override
    public void clear() {
        deque.clear();
    }
}