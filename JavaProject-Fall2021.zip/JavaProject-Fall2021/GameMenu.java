package groupprojectv2;
import java.util.Scanner;
import java.util.*;
import java.util.Queue;

public class GameMenu {
    //private static Scanner scannerInt = new Scanner(System.in);
	static BinaryTree<String> p1 = new BinaryTree<>();
	
    public static void main(String[] args) {
        boolean menu = true;
        int maxPlayers = 16;
        int currentPlayerCount = 0;
        //ArrayBag<Player> playerList = new ArrayBag<>();
        //Use list for storing player data.
        Player[] playerList = new Player[maxPlayers];
        
        //Older recent winners are at the front.
        OurDequeModified<Player> RWDeque = new OurDequeModified<>();
        
        //Older recent losers are at the front.
        OurDequeModified<Player> RLDeque = new OurDequeModified<>();
        
        //PreBuilt players so then you don't have to make them.
        
        /*
        playerList[currentPlayerCount] = new Player("John", 22);
        p1.insert("John");
        currentPlayerCount++;
        
        playerList[currentPlayerCount] = new Player("Jane", 23);
        p1.insert("Jane");
        currentPlayerCount++;
        
        playerList[currentPlayerCount] = new Player("Jojo", 21);
        p1.insert("Jojo");
        currentPlayerCount++;
        
        playerList[currentPlayerCount] = new Player("James", 22);
        p1.insert("James");
        currentPlayerCount++;
        */
        
        while (menu == true) {
        Scanner scannerInt = new Scanner(System.in);
            try {
            System.out.print("Enter 0 to display all Players.\n"
                + "Enter 1 to create a player.\n"
                + "Enter 2 to play tic-tac-toe.\n"
                + "Enter 3 to display the top 3 winner(s).\n"
                + "Enter 4 to display the recent 3 winner(s).\n"
                + "Enter 5 to display the recent 3 loser(s).\n"
                + "Enter 6 to search player name.\n"
                + "Enter 7 to search player age.\n"
                + "Enter 8 to exit.\n");
            
        double option = scannerInt.nextDouble();
        double player1Option;
        double player2Option;
        
        int number = (int)option;
        int player1;
        int player2;
        switch (number) {
                case 0: //Allows loop to exit by setting boolean menu to false.
                    for (int i = 0; i < currentPlayerCount; i++) {
                    System.out.printf("%d. %s%n", i, playerList[i].toString());
                    }
                    break;
                case 1:
                    //Go to create player
                    //Checks if more players can be made.
                    if (currentPlayerCount < maxPlayers) {
                    CreatePlayer(playerList, currentPlayerCount);
                    //Increases currentPlayerCount by 1
                    currentPlayerCount++;
                    }
                    else {
                    System.out.println("Maximum capacity reached.");
                    }
                    break;
                case 2:
                    if (currentPlayerCount < 2) {
                    System.out.println("Not enough players to start a game.");
                    }
                    else {
                    for (int i = 0; i < currentPlayerCount; i++) {
                    System.out.printf("%d. %s%n", i, playerList[i].toString());
                    }
                    System.out.println("Choose player 1: ");
                    player1Option = scannerInt.nextDouble();
                    player1 = (int)player1Option;
                    
    if (player1 < 0 || player1 >= currentPlayerCount) {
                    System.out.println("Invalid input. Returning to menu.");
                    break;
                    }
                    
                    System.out.println("Choose player 2:");
                    player2Option = scannerInt.nextDouble();
                    player2 = (int)player2Option;
                    
    if (player1 == player2 || player2 < 0 || player2 >= currentPlayerCount) {
                    System.out.println("Invalid input. Returning to menu.");
                    break;
                    }
                    //Put game code here
                    //if there's at least 2 players, play
                    System.out.println("Player 1 is \"X\" Player 2 is \"O\".");
                    int win = playGame();
                    if (win == 0) {
                        System.out.println(win);
                        playerList[player1].addWinCount();
                        playerList[player2].addLoseCount();
                        RWDeque.addToBack(playerList[player1]);
                        if (RWDeque.getSize() > 3) {
                        RWDeque.removeFront();
                        }
                        RLDeque.addToBack(playerList[player2]);
                        if (RWDeque.getSize() > 3) {
                        RLDeque.removeFront();
                        }
                        
                    }
                    else if (win == 1) {
                        System.out.println(win);
                        playerList[player2].addWinCount();
                        playerList[player1].addLoseCount();
                        RWDeque.addToBack(playerList[player2]);
                        if (RWDeque.getSize() > 3) {
                        RWDeque.removeFront();
                        }
                        RLDeque.addToBack(playerList[player1]);
                        if (RLDeque.getSize() > 3) {
                        RLDeque.removeFront();
                        }
                    }
                    else {
                    System.out.printf("No one won or lost.");
                    }
                    }
                    break;
                case 3:
                    //display the top 3 winner(s)
                    if (currentPlayerCount > 2) {
                    displayTopWinners(playerList, currentPlayerCount);
                    }
                    else {
                    System.out.print("Not enough players for top 3.");
                    }
                    //display(names, winCount);
                    break;
                case 4:
                    //display the recent 3 winner(s)
                    if (RWDeque.isEmpty()) {
                    System.out.print("Not enough players for recent 3.");
                    }
                    else {
                        for (int i = 0; i < RWDeque.getSize(); i++) {
                        System.out.println(RWDeque.getBack());
                        RWDeque.addToFront(RWDeque.removeBack());
                        }
                    }
                    System.out.println(); 
                    break;    
                case 5:
                    //display the recent 3 loser(s)
                    if (RLDeque.isEmpty()) {
                    System.out.print("Not enough players for recent 3.");
                    }
                    else {
                        for (int i = 0; i < RWDeque.getSize(); i++) {
                        System.out.println(RLDeque.getBack());
                        RLDeque.addToFront(RLDeque.removeBack());
                        }
                    }
                    System.out.println();
                    break;    
                case 6:
                	Scanner s = new Scanner(System.in);
                	System.out.print("What is the name you want to search for: ");
                	String search = s.nextLine();
                        
                        //SearchName.searchName(playerList, currentPlayerCount, search);
                        
                	if(p1.contains(search) == true)
                	System.out.print(search +" is found!\n");
                	else
                		System.out.print(search +" is not found!\n");
                        
                        
                	break;
                case 7: 
                    System.out.println("Select an age: ");
                    double ageOption = scannerInt.nextDouble();
                    int age = (int)ageOption;
                    
                    PlayerHash.searchByAge(playerList, currentPlayerCount, age);
                    break;
                case 8: //Allows loop to exit by setting boolean menu to false.
                    menu = false;
                    break;
                default:
                    System.out.print("Invalid input. ");
                    break;
            }
            System.out.println();
        }
            catch (InputMismatchException e) {
                System.out.println("Invalid input. \n");
                continue;
            }
        }

    }

    public static void CreatePlayer(Player[] list, int currentPlayerCount) {
        Scanner input = new Scanner(System.in);
        Scanner str = new Scanner(System.in);
        //BinaryTree<String> p1 = new BinaryTree<>();
            System.out.print("Enter a name: ");
            String Name = str.nextLine();
            System.out.print("Enter your age: ");
            int Age = input.nextInt();
            
            list[currentPlayerCount] = new Player(Name, Age);
            p1.insert(Name);
    }
    
    public static int playGame() {
    int playerWinner = 2;
    //0 = X (Player 1) won
    //1 = O (Player 2) won
    //2 = Draw
    tictactoe game = new tictactoe();
        game.board = new String[9];
        game.turn = "X";
        String winner = null;

        for (int a = 0; a < 9; a++) {
            game.board[a] = String.valueOf(a + 1);
        }
        game.printBoard();

        System.out.println("Enter number to place X in:");

        while (winner == null) {
            int numInput;
            Scanner in = new Scanner(System.in);
            try 
            {
                numInput = in.nextInt();
                if (!(numInput > 0 && numInput <= 9)) {
                    System.out.println("Invalid input.");
                    continue;
                }
            } 
            catch (InputMismatchException e) {
                System.out.println("Invalid input.");
                continue;
            }

            if (game.board[numInput - 1].equals(
                    String.valueOf(numInput))) {
                game.board[numInput - 1] = game.turn;

                if (game.turn.equals("X")) {
                    game.turn = "O";
                    playerWinner = 0;
                } else {
                    game.turn = "X";
                    playerWinner = 1;
                }

                game.printBoard();
                winner = game.isWinner();
            } else {
                System.out.println("Spot is already taken."
                        + " re-enter slot number:");
            }
        }

        if (winner.equalsIgnoreCase("draw")) {
            System.out.println("It's a draw");
            playerWinner = 2;
        } 
        else {
            System.out.println(winner + " has won");
        }
    return playerWinner;
    }

   public static void displayTopWinners(Player[] list, int currentPlayerCount) {
       //Default winners;
       //They have 0 wins (the minimum).
       Player Dummy = new Player("end", 0);
       Player greatest1st = Dummy;
       Player greatest2nd = Dummy;
       Player greatest3rd = Dummy;

    for (int i = 0; i < currentPlayerCount; i++){
            if (maximum(greatest1st, list[i]) == list[i]) {
            greatest1st = list[i];
            }
        }
    if (greatest1st == Dummy) {
    for (int i = 0; i < currentPlayerCount; i++){
            if (equals(greatest1st, list[i]) == list[i]) {
                greatest1st = list[i];
                break;
                }
            }
        }   
        System.out.println(greatest1st);    
        
    for (int i = 0; i < currentPlayerCount; i++){
        //skips current if it is already one of the greatest.
            if (list[i] == greatest1st) {
                continue;
            }
            if (maximum(greatest2nd, list[i]) == list[i]) {
                greatest2nd = list[i];
            }
        }
    //This occurs if a player isn't chosen for second greatest.
    //It will search for the first registered player with the same win count.
    if (greatest2nd == Dummy) {
    for (int i = 0; i < currentPlayerCount; i++){
            if (list[i] == greatest1st) {
                continue;
            }
            if (equals(greatest2nd, list[i]) == list[i]) {
                greatest2nd = list[i];
                break;
                }
            }
        }
        System.out.println(greatest2nd);
    
    for (int i = 0; i < currentPlayerCount; i++){
        //skips current if it is already one of the greatest.
            if (list[i] == greatest1st || list[i] == greatest2nd) {
                continue;
            }
            if (maximum(greatest3rd, list[i]) == list[i]) {
                greatest3rd = list[i];
            }
        }
    //This occurs if a player isn't chosen for second greatest.
    //It will search for the first registered player with the same win count.
    if (greatest3rd == Dummy) {
    for (int i = 0; i < currentPlayerCount; i++){
            if (list[i] == greatest1st || list[i] == greatest2nd) {
                continue;
            }
            if (equals(greatest3rd, list[i]) == list[i]) {
                greatest3rd = list[i];
                break;
                }
            }
        }
        System.out.println(greatest3rd);
   }
     
   public static <T extends Comparable<T>> T maximum(T a, T b) {
        //Default Maximum.
        T max = a;
        //returned value must be positive for the maximum value to change
        if (b.compareTo(max) > 0) {
            max = b;
            }
        return max;
    }
   
   public static <T extends Comparable<T>> T equals(T a, T b) {
        //Default Maximum.
        T max = a;
        //returned value must be positive for the maximum value to change
        if (b.compareTo(max) == 0) {
            max = b;
            }
        return max;
    }
}