package groupprojectv2;

public class SearchName {
    
    public static void searchName(Player[] list, int currentPlayerCount,
            String search) {
    BinaryTree<Player> p1 = new BinaryTree<>();
    
    for (int i = 0; i < currentPlayerCount; i++) {
        p1.insert(list[i]);
    }
    
    /*
    for (int i = 0; i < currentPlayerCount; i++) {
        if (p1.getName() == search);
    }*/
    
    
    
    /*
    if(p1.contains(search) == true) {
        System.out.println(search + " is found!\n");
    }
    else {
        System.out.println(search +" is not found!\n");
    }*/
}

}
